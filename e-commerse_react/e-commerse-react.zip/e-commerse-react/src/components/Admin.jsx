import AddProduct from './AddProduct';

const Admin = ({ onAddProduct }) => {
    const username = sessionStorage.getItem('username') || 'Admin';

    return (
        <div className="min-h-screen bg-gray-100 py-12">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="mb-8">
                    <h1 className="text-4xl font-bold text-gray-800 mb-2">Admin Dashboard</h1>
                    <p className="text-gray-600">Welcome, {username}! Manage your products here.</p>
                </div>

                <div className="bg-white rounded-lg shadow-md p-8">
                    <h2 className="text-2xl font-bold text-gray-800 mb-6">Add New Product</h2>
                    <AddProduct onAddProduct={onAddProduct} />
                </div>

                <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-6">
                    <h3 className="text-lg font-semibold text-blue-800 mb-2">Admin Features</h3>
                    <ul className="list-disc list-inside text-blue-700 space-y-1">
                        <li>Add new products to the store</li>
                        <li>Manage product inventory</li>
                        <li>View and process orders</li>
                        <li>Update product information</li>
                    </ul>
                </div>
            </div>
        </div>
    );
};

export default Admin;